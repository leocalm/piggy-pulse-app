import{T as a}from"./TransactionList-BSygqz0O.js";import"./iframe-tUatgIh6.js";import"./preload-helper-PPVm8Dsz.js";import"./TransactionRow-DtJ3cfNf.js";import"./currency-DAjmKDmL.js";import"./useDisplayCurrency-CYgR1z7m.js";import"./queryKeys-DbLI4zYh.js";import"./AccountBadge-XVeDKXH0.js";import"./IconMap-BmnnbRCH.js";import"./createReactComponent-CbFQ0-m9.js";import"./polymorphic-factory-ClXRxI4s.js";import"./Text-DITddzTP.js";import"./UnstyledButton-YLOeXoQt.js";import"./index-D2V8dTpW.js";import"./CategoryBadge-kwQiUj7j.js";import"./useTranslation-Cvr3ATD0.js";import"./Group-DuVf582F.js";import"./create-safe-context-BW-8o12O.js";import"./ScrollArea-CL2WNbgG.js";import"./floating-ui.react-w8eZEK3t.js";import"./use-merged-ref-BLPPl7JB.js";const I={title:"Components/Transactions/TransactionList",component:a,parameters:{layout:"fullscreen"}},t={id:"1",name:"Main Checking",color:"#228be6",icon:"wallet",accountType:"Checking",currency:{id:"1",name:"Euro",symbol:"€",currency:"EUR",decimalPlaces:2},balance:15e4,balancePerDay:[],balanceChangeThisPeriod:0,transactionCount:0},n={id:"c1",name:"Food",color:"blue",icon:"shopping-cart",parentId:null,categoryType:"Outgoing"},e={id:"v1",name:"Supermarket"},c=[{id:"t1",description:"Grocery Shopping",amount:5e3,occurredAt:"2023-10-14",category:n,fromAccount:t,toAccount:null,vendor:e},{id:"t2",description:"Salary",amount:3e5,occurredAt:"2023-10-01",category:{...n,categoryType:"Incoming",name:"Salary",icon:"cash",color:"green"},fromAccount:t,toAccount:null,vendor:{id:"v2",name:"Employer"}}],o={args:{transactions:c,deleteTransaction:async()=>{}}},r={args:{transactions:[],deleteTransaction:async()=>{}}};o.parameters={...o.parameters,docs:{...o.parameters?.docs,source:{originalSource:`{
  args: {
    transactions: mockTransactions,
    deleteTransaction: async () => {}
  }
}`,...o.parameters?.docs?.source}}};r.parameters={...r.parameters,docs:{...r.parameters?.docs,source:{originalSource:`{
  args: {
    transactions: [],
    deleteTransaction: async () => {}
  }
}`,...r.parameters?.docs?.source}}};export{o as Default,r as Empty,I as default};
