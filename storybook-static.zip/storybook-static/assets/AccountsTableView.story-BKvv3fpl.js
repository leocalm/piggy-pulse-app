import{j as s,r as u,o as d}from"./iframe-tUatgIh6.js";import{Q as h}from"./queryKeys-DbLI4zYh.js";import{A as l}from"./AccountsTableView-Bg68Aluq.js";import{Q as v}from"./queryClient-DlMq2C2w.js";import"./preload-helper-PPVm8Dsz.js";import"./CurrencyValue-Ba998bK4.js";import"./useDisplayCurrency-CYgR1z7m.js";import"./currency-DAjmKDmL.js";import"./useTranslation-Cvr3ATD0.js";import"./IconPicker-DN6Sb_h8.js";import"./IconMap-BmnnbRCH.js";import"./createReactComponent-CbFQ0-m9.js";import"./Stack-Caz3PGem.js";import"./polymorphic-factory-ClXRxI4s.js";import"./Text-DITddzTP.js";import"./Popover-DzxcNEE3.js";import"./FocusTrap-D8HI8hQ9.js";import"./Transition-wu873tAx.js";import"./UnstyledButton-YLOeXoQt.js";import"./index-D2V8dTpW.js";import"./use-merged-ref-BLPPl7JB.js";import"./use-resolved-styles-api-BVJotq1t.js";import"./floating-ui.react-w8eZEK3t.js";import"./create-safe-context-BW-8o12O.js";import"./noop-BjFrJKj1.js";import"./use-uncontrolled-BF_sGqGq.js";import"./CloseButton-BJwiWWqo.js";import"./use-click-outside-C7989IzV.js";import"./ActionIcon-qeiFNOwl.js";import"./Loader-CLPCUEQH.js";import"./TextInput-DDql-avr.js";import"./InputBase-Cg0XTyoW.js";import"./SimpleGrid-DHd5KY1h.js";import"./get-base-value-kwugXFgZ.js";import"./Skeleton-jSmvKSLK.js";import"./Title-DI-D7R-6.js";import"./Group-DuVf582F.js";import"./Button-BgfXg8kP.js";import"./AccountCard-B5dWlKmf.js";import"./Paper-CwJxeiup.js";import"./Badge-CcMb1JUk.js";import"./Divider-rYJ52p3s.js";import"./EditAccountForm-C-oVSich.js";import"./useAccounts-DH8NL-zu.js";import"./infiniteQueryBehavior-CFT3Nq9h.js";import"./use-form-DvwAxBbv.js";import"./Alert-CJ5strxe.js";import"./Grid-vtPnhZyU.js";import"./Select-CTMfex9M.js";import"./OptionsDropdown-DcWfSOfx.js";import"./ScrollArea-CL2WNbgG.js";import"./NumberInput-DrwO0Gn1.js";import"./ColorSwatch-B0lH4DkR.js";import"./Drawer-GORfhxxg.js";import"./use-window-event-DIkRYTU7.js";import"./Modal-BXvFz0em.js";const{expect:n,userEvent:B,waitFor:x,within:y}=__STORYBOOK_MODULE_TEST__,T=new v,ft={title:"Components/Accounts/AccountsTableView",component:l,parameters:{layout:"padded"},decorators:[e=>s.jsx(h,{client:T,children:s.jsx(e,{})})]},A=()=>{const[e,t]=u.useState(d),c=m=>{t(o=>o.filter(p=>p.id!==m))};return s.jsx(l,{accounts:e,isLoading:!1,onDelete:c,onAccountUpdated:()=>{}})},r={render:()=>s.jsx(A,{}),play:async({canvasElement:e})=>{const t=y(e),c=t.getAllByText("Checking");await n(c.length).toBeGreaterThan(0);const m=t.getAllByText("Savings");await n(m.length).toBeGreaterThan(0);const o=t.getAllByTitle("Delete");await n(o.length).toBeGreaterThan(0),await B.click(o[0]),await x(()=>{const g=t.queryAllByText("Checking");n(g.length).toBe(0)});const p=t.getAllByText("Savings");await n(p.length).toBeGreaterThan(0)}},a={args:{accounts:void 0,isLoading:!0,onDelete:()=>{},onAccountUpdated:()=>{}}},i={args:{accounts:[],isLoading:!1,onDelete:()=>{},onAccountUpdated:()=>{}}};r.parameters={...r.parameters,docs:{...r.parameters?.docs,source:{originalSource:`{
  render: () => <InteractiveWrapper />,
  play: async ({
    canvasElement
  }) => {
    const canvas = within(canvasElement);

    // Check if accounts are rendered
    const checkingElements = canvas.getAllByText('Checking');
    await expect(checkingElements.length).toBeGreaterThan(0);
    const savingsElements = canvas.getAllByText('Savings');
    await expect(savingsElements.length).toBeGreaterThan(0);

    // Find the delete action buttons by title attribute
    const deleteButtons = canvas.getAllByTitle('Delete');
    await expect(deleteButtons.length).toBeGreaterThan(0);

    // Click delete for the first account (Checking account)
    await userEvent.click(deleteButtons[0]);

    // Wait for account to be removed - all "Checking" texts should be gone
    await waitFor(() => {
      const remainingChecking = canvas.queryAllByText('Checking');
      expect(remainingChecking.length).toBe(0);
    });

    // Verify "Savings" account is still present
    const remainingSavings = canvas.getAllByText('Savings');
    await expect(remainingSavings.length).toBeGreaterThan(0);
  }
}`,...r.parameters?.docs?.source}}};a.parameters={...a.parameters,docs:{...a.parameters?.docs,source:{originalSource:`{
  args: {
    accounts: undefined,
    isLoading: true,
    onDelete: () => {},
    onAccountUpdated: () => {}
  }
}`,...a.parameters?.docs?.source}}};i.parameters={...i.parameters,docs:{...i.parameters?.docs,source:{originalSource:`{
  args: {
    accounts: [],
    isLoading: false,
    onDelete: () => {},
    onAccountUpdated: () => {}
  }
}`,...i.parameters?.docs?.source}}};export{i as Empty,r as Interactive,a as Loading,ft as default};
