import{C as s}from"./CategoryCard--59z906i.js";import"./iframe-tUatgIh6.js";import"./preload-helper-PPVm8Dsz.js";import"./CurrencyValue-Ba998bK4.js";import"./useDisplayCurrency-CYgR1z7m.js";import"./queryKeys-DbLI4zYh.js";import"./currency-DAjmKDmL.js";import"./useTranslation-Cvr3ATD0.js";import"./IconMap-BmnnbRCH.js";import"./createReactComponent-CbFQ0-m9.js";import"./Paper-CwJxeiup.js";import"./polymorphic-factory-ClXRxI4s.js";import"./Group-DuVf582F.js";import"./ActionIcon-qeiFNOwl.js";import"./Loader-CLPCUEQH.js";import"./Transition-wu873tAx.js";import"./UnstyledButton-YLOeXoQt.js";import"./index-D2V8dTpW.js";import"./Text-DITddzTP.js";import"./Stack-Caz3PGem.js";const O={title:"Components/Categories/CategoryCard",component:s,tags:["autodocs"],argTypes:{onEdit:{action:"edit"},onDelete:{action:"delete"},onClick:{action:"click"}}},c={id:"1",name:"Groceries",icon:"🛒",color:"#4CAF50",parentId:null,categoryType:"Outgoing"},i={id:"2",name:"Salary",icon:"💰",color:"#2196F3",parentId:null,categoryType:"Incoming"},p={id:"3",name:"Transfer",icon:"🔄",color:"#FF9800",parentId:null,categoryType:"Transfer"},n={args:{category:c,monthlySpent:45e3,transactionCount:23,trend:{direction:"up",percentage:15}}},r={args:{category:i,monthlySpent:3e5,transactionCount:2,trend:{direction:"down",percentage:5}}},e={args:{category:p,monthlySpent:1e5,transactionCount:4}},t={args:{category:{...c,name:"Entertainment",icon:"🎮",color:"#9C27B0"},monthlySpent:15e3,transactionCount:8}},o={args:{category:{...c,name:"Restaurants",icon:"🍽️",color:"#FF5722"},monthlySpent:78e3,transactionCount:45,trend:{direction:"up",percentage:22}}},a={args:{category:{...c,name:"Insurance",icon:"🛡️",color:"#607D8B"},monthlySpent:25e3,transactionCount:1,trend:{direction:"down",percentage:2}}};n.parameters={...n.parameters,docs:{...n.parameters?.docs,source:{originalSource:`{
  args: {
    category: groceriesCategory,
    monthlySpent: 45000,
    // €450.00
    transactionCount: 23,
    trend: {
      direction: 'up',
      percentage: 15
    }
  }
}`,...n.parameters?.docs?.source}}};r.parameters={...r.parameters,docs:{...r.parameters?.docs,source:{originalSource:`{
  args: {
    category: salaryCategory,
    monthlySpent: 300000,
    // €3,000.00
    transactionCount: 2,
    trend: {
      direction: 'down',
      percentage: 5
    }
  }
}`,...r.parameters?.docs?.source}}};e.parameters={...e.parameters,docs:{...e.parameters?.docs,source:{originalSource:`{
  args: {
    category: transferCategory,
    monthlySpent: 100000,
    // €1,000.00
    transactionCount: 4
  }
}`,...e.parameters?.docs?.source}}};t.parameters={...t.parameters,docs:{...t.parameters?.docs,source:{originalSource:`{
  args: {
    category: {
      ...groceriesCategory,
      name: 'Entertainment',
      icon: '🎮',
      color: '#9C27B0'
    },
    monthlySpent: 15000,
    transactionCount: 8
  }
}`,...t.parameters?.docs?.source}}};o.parameters={...o.parameters,docs:{...o.parameters?.docs,source:{originalSource:`{
  args: {
    category: {
      ...groceriesCategory,
      name: 'Restaurants',
      icon: '🍽️',
      color: '#FF5722'
    },
    monthlySpent: 78000,
    transactionCount: 45,
    trend: {
      direction: 'up',
      percentage: 22
    }
  }
}`,...o.parameters?.docs?.source}}};a.parameters={...a.parameters,docs:{...a.parameters?.docs,source:{originalSource:`{
  args: {
    category: {
      ...groceriesCategory,
      name: 'Insurance',
      icon: '🛡️',
      color: '#607D8B'
    },
    monthlySpent: 25000,
    transactionCount: 1,
    trend: {
      direction: 'down',
      percentage: 2
    }
  }
}`,...a.parameters?.docs?.source}}};export{o as HighActivity,r as Incoming,a as LowActivity,t as NoTrend,n as Outgoing,e as Transfer,O as default};
