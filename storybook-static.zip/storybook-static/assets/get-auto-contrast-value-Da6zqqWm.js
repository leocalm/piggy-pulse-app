function e(t,o){return typeof t=="boolean"?t:o.autoContrast}export{e as g};
