import{o as t}from"./iframe-tUatgIh6.js";import{aR as e}from"./AccountCard-B5dWlKmf.js";import"./preload-helper-PPVm8Dsz.js";import"./currency-DAjmKDmL.js";import"./CurrencyValue-Ba998bK4.js";import"./useDisplayCurrency-CYgR1z7m.js";import"./queryKeys-DbLI4zYh.js";import"./useTranslation-Cvr3ATD0.js";import"./Paper-CwJxeiup.js";import"./polymorphic-factory-ClXRxI4s.js";import"./Group-DuVf582F.js";import"./Title-DI-D7R-6.js";import"./Badge-CcMb1JUk.js";import"./ActionIcon-qeiFNOwl.js";import"./Loader-CLPCUEQH.js";import"./Transition-wu873tAx.js";import"./UnstyledButton-YLOeXoQt.js";import"./index-D2V8dTpW.js";import"./Text-DITddzTP.js";import"./Divider-rYJ52p3s.js";import"./SimpleGrid-DHd5KY1h.js";import"./get-base-value-kwugXFgZ.js";import"./Stack-Caz3PGem.js";import"./Button-BgfXg8kP.js";const R={title:"Components/Accounts/AccountCard",component:e,tags:["autodocs"],argTypes:{onEdit:{action:"edit"},onDelete:{action:"delete"}}},n={args:{account:t[0],balanceHistory:[{date:"2026-01-01",balance:145e3},{date:"2026-01-05",balance:147e3},{date:"2026-01-10",balance:148500},{date:"2026-01-15",balance:15e4}],monthlySpent:12500,transactionCount:23}},a={args:{account:{...t[0],name:"Spending Account",color:"orange",spendLimit:5e4},balanceHistory:[{date:"2026-01-01",balance:145e3},{date:"2026-01-05",balance:147e3},{date:"2026-01-10",balance:148500},{date:"2026-01-15",balance:15e4}],monthlySpent:12500,transactionCount:23}};n.parameters={...n.parameters,docs:{...n.parameters?.docs,source:{originalSource:`{
  args: {
    account: mockAccounts[0],
    balanceHistory: [{
      date: '2026-01-01',
      balance: 145000
    }, {
      date: '2026-01-05',
      balance: 147000
    }, {
      date: '2026-01-10',
      balance: 148500
    }, {
      date: '2026-01-15',
      balance: 150000
    }],
    monthlySpent: 12500,
    transactionCount: 23
  }
}`,...n.parameters?.docs?.source}}};a.parameters={...a.parameters,docs:{...a.parameters?.docs,source:{originalSource:`{
  args: {
    account: {
      ...mockAccounts[0],
      name: 'Spending Account',
      color: 'orange',
      spendLimit: 50000 // 500.00
    },
    balanceHistory: [{
      date: '2026-01-01',
      balance: 145000
    }, {
      date: '2026-01-05',
      balance: 147000
    }, {
      date: '2026-01-10',
      balance: 148500
    }, {
      date: '2026-01-15',
      balance: 150000
    }],
    monthlySpent: 12500,
    transactionCount: 23
  }
}`,...a.parameters?.docs?.source}}};export{n as Default,a as WithSpendLimit,R as default};
