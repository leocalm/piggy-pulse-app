import{j as e,r as m}from"./iframe-tUatgIh6.js";import{I as p}from"./IconPicker-DN6Sb_h8.js";import"./preload-helper-PPVm8Dsz.js";import"./IconMap-BmnnbRCH.js";import"./createReactComponent-CbFQ0-m9.js";import"./Stack-Caz3PGem.js";import"./polymorphic-factory-ClXRxI4s.js";import"./Text-DITddzTP.js";import"./Popover-DzxcNEE3.js";import"./FocusTrap-D8HI8hQ9.js";import"./Transition-wu873tAx.js";import"./UnstyledButton-YLOeXoQt.js";import"./index-D2V8dTpW.js";import"./use-merged-ref-BLPPl7JB.js";import"./use-resolved-styles-api-BVJotq1t.js";import"./floating-ui.react-w8eZEK3t.js";import"./create-safe-context-BW-8o12O.js";import"./noop-BjFrJKj1.js";import"./use-uncontrolled-BF_sGqGq.js";import"./CloseButton-BJwiWWqo.js";import"./use-click-outside-C7989IzV.js";import"./ActionIcon-qeiFNOwl.js";import"./Loader-CLPCUEQH.js";import"./TextInput-DDql-avr.js";import"./InputBase-Cg0XTyoW.js";import"./SimpleGrid-DHd5KY1h.js";import"./get-base-value-kwugXFgZ.js";const V={title:"Components/Utils/IconPicker",component:p,tags:["autodocs"]},n=r=>{const[c,i]=m.useState(r.value);return e.jsx(p,{value:c,onChange:i,label:r.label})},o={render:r=>e.jsx(n,{...r}),args:{value:"IconHome"}},a={render:r=>e.jsx(n,{...r}),args:{value:"IconShoppingCart",label:"Choose an icon"}},t={render:r=>e.jsx(n,{...r}),args:{value:"IconToolsKitchen2"}},s={render:r=>e.jsx(n,{...r}),args:{value:"IconCurrencyDollar"}};o.parameters={...o.parameters,docs:{...o.parameters?.docs,source:{originalSource:`{
  render: args => <InteractiveWrapper {...args} />,
  args: {
    value: 'IconHome'
  }
}`,...o.parameters?.docs?.source}}};a.parameters={...a.parameters,docs:{...a.parameters?.docs,source:{originalSource:`{
  render: args => <InteractiveWrapper {...args} />,
  args: {
    value: 'IconShoppingCart',
    label: 'Choose an icon'
  }
}`,...a.parameters?.docs?.source}}};t.parameters={...t.parameters,docs:{...t.parameters?.docs,source:{originalSource:`{
  render: args => <InteractiveWrapper {...args} />,
  args: {
    value: 'IconToolsKitchen2'
  }
}`,...t.parameters?.docs?.source}}};s.parameters={...s.parameters,docs:{...s.parameters?.docs,source:{originalSource:`{
  render: args => <InteractiveWrapper {...args} />,
  args: {
    value: 'IconCurrencyDollar'
  }
}`,...s.parameters?.docs?.source}}};export{o as Default,t as FoodIcon,s as MoneyIcon,a as WithLabel,V as default};
