import{j as a}from"./iframe-tUatgIh6.js";import{A as c}from"./AccountBadge-XVeDKXH0.js";import{B as s}from"./polymorphic-factory-ClXRxI4s.js";import{G as u}from"./Group-DuVf582F.js";import"./preload-helper-PPVm8Dsz.js";import"./IconMap-BmnnbRCH.js";import"./createReactComponent-CbFQ0-m9.js";import"./Text-DITddzTP.js";const h={title:"Components/Transactions/AccountBadge",component:c,decorators:[i=>a.jsx(s,{p:"lg",style:{background:"#0a0e14"},children:a.jsx(i,{})})]},n={id:"1",name:"Euro",symbol:"€",currency:"EUR",decimalPlaces:2},e={args:{account:{id:"1",name:"ING",color:"#ff6600",icon:"💳",accountType:"Checking",currency:n,balance:15e4,balancePerDay:[],balanceChangeThisPeriod:0,transactionCount:0}}},r={args:{account:{id:"2",name:"Poupança",color:"#00ffa3",icon:"🏦",accountType:"Savings",currency:n,balance:5e5,balancePerDay:[],balanceChangeThisPeriod:0,transactionCount:0}}},o={args:{account:{id:"3",name:"AMEX",color:"#00d4ff",icon:"💳",accountType:"CreditCard",currency:n,balance:-25e3,balancePerDay:[],balanceChangeThisPeriod:0,transactionCount:0}}},t={render:()=>a.jsxs(u,{gap:"md",children:[a.jsx(c,{account:{id:"1",name:"ING",color:"#ff6600",icon:"💳",accountType:"Checking",currency:n,balance:15e4,balancePerDay:[],balanceChangeThisPeriod:0,transactionCount:0}}),a.jsx(c,{account:{id:"2",name:"Poupança ING",color:"#00ffa3",icon:"🏦",accountType:"Savings",currency:n,balance:5e5,balancePerDay:[],balanceChangeThisPeriod:0,transactionCount:0}}),a.jsx(c,{account:{id:"3",name:"AMEX",color:"#00d4ff",icon:"💳",accountType:"CreditCard",currency:n,balance:-25e3,balancePerDay:[],balanceChangeThisPeriod:0,transactionCount:0}}),a.jsx(c,{account:{id:"4",name:"Revolut",color:"#b47aff",icon:"💳",accountType:"Checking",currency:n,balance:75e3,balancePerDay:[],balanceChangeThisPeriod:0,transactionCount:0}})]})};e.parameters={...e.parameters,docs:{...e.parameters?.docs,source:{originalSource:`{
  args: {
    account: {
      id: '1',
      name: 'ING',
      color: '#ff6600',
      icon: '💳',
      accountType: 'Checking',
      currency: mockCurrency,
      balance: 150000,
      balancePerDay: [],
      balanceChangeThisPeriod: 0,
      transactionCount: 0
    }
  }
}`,...e.parameters?.docs?.source}}};r.parameters={...r.parameters,docs:{...r.parameters?.docs,source:{originalSource:`{
  args: {
    account: {
      id: '2',
      name: 'Poupança',
      color: '#00ffa3',
      icon: '🏦',
      accountType: 'Savings',
      currency: mockCurrency,
      balance: 500000,
      balancePerDay: [],
      balanceChangeThisPeriod: 0,
      transactionCount: 0
    }
  }
}`,...r.parameters?.docs?.source}}};o.parameters={...o.parameters,docs:{...o.parameters?.docs,source:{originalSource:`{
  args: {
    account: {
      id: '3',
      name: 'AMEX',
      color: '#00d4ff',
      icon: '💳',
      accountType: 'CreditCard',
      currency: mockCurrency,
      balance: -25000,
      balancePerDay: [],
      balanceChangeThisPeriod: 0,
      transactionCount: 0
    }
  }
}`,...o.parameters?.docs?.source}}};t.parameters={...t.parameters,docs:{...t.parameters?.docs,source:{originalSource:`{
  render: () => <Group gap="md">
      <AccountBadge account={{
      id: '1',
      name: 'ING',
      color: '#ff6600',
      icon: '💳',
      accountType: 'Checking',
      currency: mockCurrency,
      balance: 150000,
      balancePerDay: [],
      balanceChangeThisPeriod: 0,
      transactionCount: 0
    }} />
      <AccountBadge account={{
      id: '2',
      name: 'Poupança ING',
      color: '#00ffa3',
      icon: '🏦',
      accountType: 'Savings',
      currency: mockCurrency,
      balance: 500000,
      balancePerDay: [],
      balanceChangeThisPeriod: 0,
      transactionCount: 0
    }} />
      <AccountBadge account={{
      id: '3',
      name: 'AMEX',
      color: '#00d4ff',
      icon: '💳',
      accountType: 'CreditCard',
      currency: mockCurrency,
      balance: -25000,
      balancePerDay: [],
      balanceChangeThisPeriod: 0,
      transactionCount: 0
    }} />
      <AccountBadge account={{
      id: '4',
      name: 'Revolut',
      color: '#b47aff',
      icon: '💳',
      accountType: 'Checking',
      currency: mockCurrency,
      balance: 75000,
      balancePerDay: [],
      balanceChangeThisPeriod: 0,
      transactionCount: 0
    }} />
    </Group>
}`,...t.parameters?.docs?.source}}};export{t as AllVariants,e as Checking,o as CreditCard,r as Savings,h as default};
