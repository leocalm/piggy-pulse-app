import{T as e}from"./TransactionStats-By576-IO.js";import"./iframe-tUatgIh6.js";import"./preload-helper-PPVm8Dsz.js";import"./currency-DAjmKDmL.js";import"./useDisplayCurrency-CYgR1z7m.js";import"./queryKeys-DbLI4zYh.js";import"./useTranslation-Cvr3ATD0.js";import"./SimpleGrid-DHd5KY1h.js";import"./polymorphic-factory-ClXRxI4s.js";import"./get-base-value-kwugXFgZ.js";import"./Text-DITddzTP.js";const d={title:"Components/Transactions/TransactionStats",component:e},t={args:{income:1e5,balance:1e4,expenses:9e4}};t.parameters={...t.parameters,docs:{...t.parameters?.docs,source:{originalSource:`{
  args: {
    income: 100000,
    balance: 10000,
    expenses: 90000
  }
}`,...t.parameters?.docs?.source}}};export{t as Default,d as default};
