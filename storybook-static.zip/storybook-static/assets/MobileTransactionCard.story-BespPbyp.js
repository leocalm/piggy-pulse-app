import{M as e}from"./MobileTransactionCard-CRu5OKiH.js";import"./iframe-tUatgIh6.js";import"./preload-helper-PPVm8Dsz.js";import"./CurrencyValue-Ba998bK4.js";import"./useDisplayCurrency-CYgR1z7m.js";import"./queryKeys-DbLI4zYh.js";import"./currency-DAjmKDmL.js";import"./useTranslation-Cvr3ATD0.js";import"./IconMap-BmnnbRCH.js";import"./createReactComponent-CbFQ0-m9.js";import"./Card-B_RyWbI_.js";import"./polymorphic-factory-ClXRxI4s.js";import"./Paper-CwJxeiup.js";import"./create-safe-context-BW-8o12O.js";import"./Group-DuVf582F.js";import"./ActionIcon-qeiFNOwl.js";import"./Loader-CLPCUEQH.js";import"./Transition-wu873tAx.js";import"./UnstyledButton-YLOeXoQt.js";import"./index-D2V8dTpW.js";import"./IconRepeat-BXDID1CS.js";import"./Text-DITddzTP.js";const E={title:"Components/Transactions/MobileTransactionCard",component:e},n={id:"1",name:"Main Checking",color:"#228be6",icon:"wallet",accountType:"Checking",currency:{id:"1",name:"Euro",symbol:"€",currency:"EUR",decimalPlaces:2},balance:15e4,balancePerDay:[],balanceChangeThisPeriod:0,transactionCount:0},t={id:"c1",name:"Food",color:"blue",icon:"shopping-cart",parentId:null,categoryType:"Outgoing"},c={id:"v1",name:"Supermarket"},a={id:"t1",description:"Grocery Shopping",amount:5e3,occurredAt:"2023-10-14",category:t,fromAccount:n,toAccount:null,vendor:c},o={args:{transaction:a}},r={args:{transaction:{...a,category:{...t,categoryType:"Transfer",name:"Transfer",icon:"arrows-left-right"},toAccount:{...n,id:"2",name:"Savings",color:"green"},description:""}}};o.parameters={...o.parameters,docs:{...o.parameters?.docs,source:{originalSource:`{
  args: {
    transaction: mockTransaction
  }
}`,...o.parameters?.docs?.source}}};r.parameters={...r.parameters,docs:{...r.parameters?.docs,source:{originalSource:`{
  args: {
    transaction: {
      ...mockTransaction,
      category: {
        ...mockCategory,
        categoryType: 'Transfer',
        name: 'Transfer',
        icon: 'arrows-left-right'
      },
      toAccount: {
        ...mockAccount,
        id: '2',
        name: 'Savings',
        color: 'green'
      },
      description: ''
    }
  }
}`,...r.parameters?.docs?.source}}};export{o as Default,r as Transfer,E as default};
