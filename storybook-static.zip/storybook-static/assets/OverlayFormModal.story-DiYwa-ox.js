import{j as r}from"./iframe-tUatgIh6.js";import{Q as u}from"./queryKeys-DbLI4zYh.js";import{O as i}from"./OverlayFormModal-C4gGyOco.js";import{u as c}from"./Drawer-GORfhxxg.js";import{B as s}from"./Button-BgfXg8kP.js";import{Q as y}from"./queryClient-DlMq2C2w.js";import"./preload-helper-PPVm8Dsz.js";import"./useDisplayCurrency-CYgR1z7m.js";import"./currency-DAjmKDmL.js";import"./useTranslation-Cvr3ATD0.js";import"./UnstyledButton-YLOeXoQt.js";import"./index-D2V8dTpW.js";import"./polymorphic-factory-ClXRxI4s.js";import"./Stack-Caz3PGem.js";import"./TextInput-DDql-avr.js";import"./InputBase-Cg0XTyoW.js";import"./CloseButton-BJwiWWqo.js";import"./use-resolved-styles-api-BVJotq1t.js";import"./Group-DuVf582F.js";import"./Text-DITddzTP.js";import"./Paper-CwJxeiup.js";import"./Badge-CcMb1JUk.js";import"./Alert-CJ5strxe.js";import"./createReactComponent-CbFQ0-m9.js";import"./OptionsDropdown-DcWfSOfx.js";import"./ScrollArea-CL2WNbgG.js";import"./floating-ui.react-w8eZEK3t.js";import"./create-safe-context-BW-8o12O.js";import"./use-merged-ref-BLPPl7JB.js";import"./Popover-DzxcNEE3.js";import"./FocusTrap-D8HI8hQ9.js";import"./Transition-wu873tAx.js";import"./noop-BjFrJKj1.js";import"./use-uncontrolled-BF_sGqGq.js";import"./use-click-outside-C7989IzV.js";import"./InputsGroupFieldset-eoc1csEK.js";import"./NumberInput-DrwO0Gn1.js";import"./Divider-rYJ52p3s.js";import"./IconAlertTriangle-BFOV1LBV.js";import"./get-auto-contrast-value-Da6zqqWm.js";import"./Loader-CLPCUEQH.js";import"./IconDeviceFloppy-CtBH9IOA.js";import"./IconPlus-RUg_QOoP.js";import"./Modal-BXvFz0em.js";import"./notifications.store-CpLOc3ee.js";import"./use-window-event-DIkRYTU7.js";import"./infiniteQueryBehavior-CFT3Nq9h.js";const g=new y({defaultOptions:{queries:{retry:!1}}}),p=[{id:"category-1",name:"Travel",icon:"✈️",color:"#00d4ff",parentId:null,categoryType:"Outgoing",usedInPeriod:0,differenceVsAveragePercentage:0,transactionCount:0},{id:"category-2",name:"Hotels",icon:"🏨",color:"#00d4ff",parentId:null,categoryType:"Outgoing",usedInPeriod:0,differenceVsAveragePercentage:0,transactionCount:0}],m=[{id:"vendor-1",name:"Airline Co",transactionCount:0},{id:"vendor-2",name:"Hotel Group",transactionCount:0}],d=[{id:"account-1",name:"Main Checking",icon:"💳",color:"#00d4ff",accountType:"Checking",currency:{id:"currency-eur",name:"Euro",symbol:"€",currency:"EUR",decimalPlaces:2},balance:0,balancePerDay:[],balanceChangeThisPeriod:0,transactionCount:0}],dr={title:"Components/Overlays/OverlayFormModal",component:i,decorators:[o=>r.jsx(u,{client:g,children:r.jsx(o,{})})]},C=()=>{const[o,{open:n,close:a}]=c(!0);return r.jsxs(r.Fragment,{children:[r.jsx(s,{onClick:n,children:"Open"}),r.jsx(i,{opened:o,onClose:a,categories:p,vendors:m,accounts:d})]})},v=({overlay:o})=>{const[n,{open:a,close:l}]=c(!0);return r.jsxs(r.Fragment,{children:[r.jsx(s,{onClick:a,children:"Open"}),r.jsx(i,{opened:n,onClose:l,overlay:o,categories:p,vendors:m,accounts:d})]})},e={render:()=>r.jsx(C,{})},t={render:()=>r.jsx(v,{overlay:{id:"overlay-1",name:"Italy Trip",icon:"🏖️",startDate:"2026-08-10",endDate:"2026-08-20",inclusionMode:"rules",rules:{categoryIds:["category-1"],vendorIds:["vendor-1"],accountIds:["account-1"]},totalCapAmount:8e4,categoryCaps:[{categoryId:"category-1",capAmount:3e4}]}})};e.parameters={...e.parameters,docs:{...e.parameters?.docs,source:{originalSource:`{
  render: () => <ModalWrapper />
}`,...e.parameters?.docs?.source}}};t.parameters={...t.parameters,docs:{...t.parameters?.docs,source:{originalSource:`{
  render: () => <ModalWrapperWithOverlay overlay={{
    id: 'overlay-1',
    name: 'Italy Trip',
    icon: '🏖️',
    startDate: '2026-08-10',
    endDate: '2026-08-20',
    inclusionMode: 'rules',
    rules: {
      categoryIds: ['category-1'],
      vendorIds: ['vendor-1'],
      accountIds: ['account-1']
    },
    totalCapAmount: 80000,
    categoryCaps: [{
      categoryId: 'category-1',
      capAmount: 30000
    }]
  }} />
}`,...t.parameters?.docs?.source}}};export{e as CreateMode,t as EditMode,dr as default};
