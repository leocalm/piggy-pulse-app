import{c as o}from"./createReactComponent-CbFQ0-m9.js";const t=[["path",{d:"M12 5l0 14",key:"svg-0"}],["path",{d:"M5 12l14 0",key:"svg-1"}]],s=o("outline","plus","Plus",t);export{s as I};
