import{u as g,j as e}from"./iframe-tUatgIh6.js";import{C as a}from"./Container-BW0QULvH.js";import{T as r}from"./Title-DI-D7R-6.js";import{S as n}from"./Stack-Caz3PGem.js";import{T as t}from"./Text-DITddzTP.js";import{G as p}from"./Group-DuVf582F.js";import{G as h}from"./Grid-vtPnhZyU.js";import{C as T}from"./ColorSwatch-B0lH4DkR.js";import"./preload-helper-PPVm8Dsz.js";import"./polymorphic-factory-ClXRxI4s.js";import"./create-safe-context-BW-8o12O.js";import"./get-base-value-kwugXFgZ.js";const v={title:"Design System"},o=({title:s,colors:x})=>e.jsxs(n,{gap:"xs",mb:"xl",children:[e.jsx(r,{order:4,children:s}),e.jsx(h,{children:x.map((c,m)=>e.jsx(h.Col,{span:{base:6,sm:3,md:2},children:e.jsxs(n,{gap:4,align:"center",children:[e.jsx(T,{color:c,size:40,radius:"md"}),e.jsx(t,{size:"xs",c:"dimmed",children:m}),e.jsx(t,{size:"xs",fw:500,children:c.toUpperCase()})]})},m))})]}),i=()=>{const s=g();return e.jsxs(a,{size:"lg",py:"xl",children:[e.jsx(r,{order:1,mb:"xl",children:"Design System - Palette"}),e.jsxs(n,{gap:"xl",children:[e.jsxs("section",{children:[e.jsx(r,{order:2,mb:"md",children:"Brand Colors"}),e.jsx(o,{title:"Primary (Cyan)",colors:s.colors.cyan})]}),e.jsxs("section",{children:[e.jsx(r,{order:2,mb:"md",children:"Semantic Colors"}),e.jsx(o,{title:"Success (Green)",colors:s.colors.green}),e.jsx(o,{title:"Warning (Orange)",colors:s.colors.orange}),e.jsx(o,{title:"Danger (Pink)",colors:s.colors.pink}),e.jsx(o,{title:"Info (Violet)",colors:s.colors.violet})]}),e.jsxs("section",{children:[e.jsx(r,{order:2,mb:"md",children:"Neutral Colors"}),e.jsx(o,{title:"Dark (Backgrounds & Surfaces)",colors:s.colors.dark})]})]})]})},l=()=>{const s=g();return e.jsxs(a,{size:"lg",py:"xl",children:[e.jsx(r,{order:1,mb:"xl",children:"Design System - Typography"}),e.jsxs(n,{gap:"xl",children:[e.jsxs("section",{children:[e.jsx(r,{order:2,mb:"md",children:"Headings"}),e.jsxs(n,{gap:"md",children:[e.jsxs(r,{order:1,children:["Heading 1 - ",s.headings.fontWeight," Weight"]}),e.jsxs(r,{order:2,children:["Heading 2 - ",s.headings.fontWeight," Weight"]}),e.jsxs(r,{order:3,children:["Heading 3 - ",s.headings.fontWeight," Weight"]}),e.jsxs(r,{order:4,children:["Heading 4 - ",s.headings.fontWeight," Weight"]}),e.jsxs(r,{order:5,children:["Heading 5 - ",s.headings.fontWeight," Weight"]}),e.jsxs(r,{order:6,children:["Heading 6 - ",s.headings.fontWeight," Weight"]})]})]}),e.jsxs("section",{children:[e.jsx(r,{order:2,mb:"md",children:"Body Text"}),e.jsxs(n,{gap:"md",children:[e.jsx(t,{size:"xl",children:"Extra Large Text - The quick brown fox jumps over the lazy dog"}),e.jsx(t,{size:"lg",children:"Large Text - The quick brown fox jumps over the lazy dog"}),e.jsx(t,{size:"md",children:"Medium Text (Default) - The quick brown fox jumps over the lazy dog"}),e.jsx(t,{size:"sm",children:"Small Text - The quick brown fox jumps over the lazy dog"}),e.jsx(t,{size:"xs",children:"Extra Small Text - The quick brown fox jumps over the lazy dog"})]})]}),e.jsxs("section",{children:[e.jsx(r,{order:2,mb:"md",children:"Monospace"}),e.jsx(t,{ff:"monospace",size:"md",children:'const designSystem = "Piggy Pulse"; console.log(designSystem);'})]})]})]})},d=()=>e.jsxs(a,{size:"lg",py:"xl",children:[e.jsx(r,{order:1,mb:"xl",children:"Design System - Brand Elements"}),e.jsxs(n,{gap:"xl",children:[e.jsxs("section",{children:[e.jsx(r,{order:2,mb:"md",children:"Gradients"}),e.jsx(p,{children:e.jsxs(n,{align:"center",children:[e.jsx("div",{className:"brand-gradient",style:{width:200,height:100,borderRadius:12}}),e.jsx(t,{size:"sm",children:"Brand Gradient"})]})})]}),e.jsxs("section",{children:[e.jsx(r,{order:2,mb:"md",children:"Typography FX"}),e.jsx(r,{order:1,className:"brand-text",children:"Piggy Pulse Brand Text"})]}),e.jsxs("section",{children:[e.jsx(r,{order:2,mb:"md",children:"Glow Effects"}),e.jsx("div",{className:"brand-gradient brand-glow",style:{width:100,height:100,borderRadius:"50%"}})]})]})]});i.__docgenInfo={description:"",methods:[],displayName:"Palette"};l.__docgenInfo={description:"",methods:[],displayName:"Typography"};d.__docgenInfo={description:"",methods:[],displayName:"BrandElements"};i.parameters={...i.parameters,docs:{...i.parameters?.docs,source:{originalSource:`() => {
  const theme = useMantineTheme();
  return <Container size="lg" py="xl">
      <Title order={1} mb="xl">Design System - Palette</Title>
      
      <Stack gap="xl">
        <section>
          <Title order={2} mb="md">Brand Colors</Title>
          <ColorGroup title="Primary (Cyan)" colors={theme.colors.cyan} />
        </section>

        <section>
          <Title order={2} mb="md">Semantic Colors</Title>
          <ColorGroup title="Success (Green)" colors={theme.colors.green} />
          <ColorGroup title="Warning (Orange)" colors={theme.colors.orange} />
          <ColorGroup title="Danger (Pink)" colors={theme.colors.pink} />
          <ColorGroup title="Info (Violet)" colors={theme.colors.violet} />
        </section>

        <section>
          <Title order={2} mb="md">Neutral Colors</Title>
          <ColorGroup title="Dark (Backgrounds & Surfaces)" colors={theme.colors.dark} />
        </section>
      </Stack>
    </Container>;
}`,...i.parameters?.docs?.source}}};l.parameters={...l.parameters,docs:{...l.parameters?.docs,source:{originalSource:`() => {
  const theme = useMantineTheme();
  return <Container size="lg" py="xl">
      <Title order={1} mb="xl">Design System - Typography</Title>
      
      <Stack gap="xl">
        <section>
          <Title order={2} mb="md">Headings</Title>
          <Stack gap="md">
            <Title order={1}>Heading 1 - {theme.headings.fontWeight} Weight</Title>
            <Title order={2}>Heading 2 - {theme.headings.fontWeight} Weight</Title>
            <Title order={3}>Heading 3 - {theme.headings.fontWeight} Weight</Title>
            <Title order={4}>Heading 4 - {theme.headings.fontWeight} Weight</Title>
            <Title order={5}>Heading 5 - {theme.headings.fontWeight} Weight</Title>
            <Title order={6}>Heading 6 - {theme.headings.fontWeight} Weight</Title>
          </Stack>
        </section>

        <section>
          <Title order={2} mb="md">Body Text</Title>
          <Stack gap="md">
            <Text size="xl">Extra Large Text - The quick brown fox jumps over the lazy dog</Text>
            <Text size="lg">Large Text - The quick brown fox jumps over the lazy dog</Text>
            <Text size="md">Medium Text (Default) - The quick brown fox jumps over the lazy dog</Text>
            <Text size="sm">Small Text - The quick brown fox jumps over the lazy dog</Text>
            <Text size="xs">Extra Small Text - The quick brown fox jumps over the lazy dog</Text>
          </Stack>
        </section>

        <section>
          <Title order={2} mb="md">Monospace</Title>
          <Text ff="monospace" size="md">
            const designSystem = "Piggy Pulse";
            console.log(designSystem);
          </Text>
        </section>
      </Stack>
    </Container>;
}`,...l.parameters?.docs?.source}}};d.parameters={...d.parameters,docs:{...d.parameters?.docs,source:{originalSource:`() => {
  return <Container size="lg" py="xl">
            <Title order={1} mb="xl">Design System - Brand Elements</Title>

            <Stack gap="xl">
                <section>
                    <Title order={2} mb="md">Gradients</Title>
                    <Group>
                        <Stack align="center">
                            <div className="brand-gradient" style={{
              width: 200,
              height: 100,
              borderRadius: 12
            }} />
                            <Text size="sm">Brand Gradient</Text>
                        </Stack>
                    </Group>
                </section>

                <section>
                    <Title order={2} mb="md">Typography FX</Title>
                    <Title order={1} className="brand-text">Piggy Pulse Brand Text</Title>
                </section>

                <section>
                    <Title order={2} mb="md">Glow Effects</Title>
                    <div className="brand-gradient brand-glow" style={{
          width: 100,
          height: 100,
          borderRadius: '50%'
        }} />
                </section>
            </Stack>
        </Container>;
}`,...d.parameters?.docs?.source}}};export{d as BrandElements,i as Palette,l as Typography,v as default};
