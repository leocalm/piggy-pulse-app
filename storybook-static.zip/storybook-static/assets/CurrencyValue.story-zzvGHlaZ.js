import{C as u}from"./CurrencyValue-Ba998bK4.js";import"./iframe-tUatgIh6.js";import"./preload-helper-PPVm8Dsz.js";import"./useDisplayCurrency-CYgR1z7m.js";import"./queryKeys-DbLI4zYh.js";import"./currency-DAjmKDmL.js";import"./useTranslation-Cvr3ATD0.js";const S={title:"Components/Utils/CurrencyValue",component:u,tags:["autodocs"]},o={id:"1",name:"Euro",symbol:"€",currency:"EUR",decimalPlaces:2},t={id:"2",name:"US Dollar",symbol:"$",currency:"USD",decimalPlaces:2},m={id:"3",name:"British Pound",symbol:"£",currency:"GBP",decimalPlaces:2},r={args:{currency:o,cents:15e4}},e={args:{currency:t,cents:250050}},c={args:{currency:m,cents:99999}},s={args:{currency:void 0,cents:123456}},n={args:{currency:o,cents:0}},a={args:{currency:t,cents:-50025}};r.parameters={...r.parameters,docs:{...r.parameters?.docs,source:{originalSource:`{
  args: {
    currency: euroCurrency,
    cents: 150000
  }
}`,...r.parameters?.docs?.source}}};e.parameters={...e.parameters,docs:{...e.parameters?.docs,source:{originalSource:`{
  args: {
    currency: dollarCurrency,
    cents: 250050
  }
}`,...e.parameters?.docs?.source}}};c.parameters={...c.parameters,docs:{...c.parameters?.docs,source:{originalSource:`{
  args: {
    currency: poundCurrency,
    cents: 99999
  }
}`,...c.parameters?.docs?.source}}};s.parameters={...s.parameters,docs:{...s.parameters?.docs,source:{originalSource:`{
  args: {
    currency: undefined,
    cents: 123456
  }
}`,...s.parameters?.docs?.source}}};n.parameters={...n.parameters,docs:{...n.parameters?.docs,source:{originalSource:`{
  args: {
    currency: euroCurrency,
    cents: 0
  }
}`,...n.parameters?.docs?.source}}};a.parameters={...a.parameters,docs:{...a.parameters?.docs,source:{originalSource:`{
  args: {
    currency: dollarCurrency,
    cents: -50025
  }
}`,...a.parameters?.docs?.source}}};export{e as Dollar,r as Euro,a as NegativeValue,s as NoCurrency,c as Pound,n as ZeroValue,S as default};
