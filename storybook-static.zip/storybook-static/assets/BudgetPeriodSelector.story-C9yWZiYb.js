import{j as r,r as m}from"./iframe-tUatgIh6.js";import{B as i}from"./BudgetPeriodSelector-CREnr_nN.js";import{B as l}from"./polymorphic-factory-ClXRxI4s.js";import"./preload-helper-PPVm8Dsz.js";import"./useTranslation-Cvr3ATD0.js";import"./Drawer-GORfhxxg.js";import"./FocusTrap-D8HI8hQ9.js";import"./Transition-wu873tAx.js";import"./UnstyledButton-YLOeXoQt.js";import"./index-D2V8dTpW.js";import"./use-merged-ref-BLPPl7JB.js";import"./create-safe-context-BW-8o12O.js";import"./CloseButton-BJwiWWqo.js";import"./Paper-CwJxeiup.js";import"./floating-ui.react-w8eZEK3t.js";import"./use-window-event-DIkRYTU7.js";import"./ScrollArea-CL2WNbgG.js";import"./use-click-outside-C7989IzV.js";import"./Stack-Caz3PGem.js";import"./Text-DITddzTP.js";import"./Button-BgfXg8kP.js";import"./Loader-CLPCUEQH.js";import"./Group-DuVf582F.js";import"./Badge-CcMb1JUk.js";import"./Alert-CJ5strxe.js";import"./IconAlertTriangle-BFOV1LBV.js";import"./createReactComponent-CbFQ0-m9.js";import"./Divider-rYJ52p3s.js";const a=[{id:"period-current",name:"February 2026",startDate:"2026-02-01",endDate:"2026-02-28"},{id:"period-next",name:"March 2026",startDate:"2026-03-01",endDate:"2026-03-31"},{id:"period-prev",name:"January 2026",startDate:"2026-01-01",endDate:"2026-01-31"}],H={title:"Components/BudgetPeriodSelector",component:i,tags:["autodocs"],decorators:[e=>r.jsx(l,{maw:360,p:"md",children:r.jsx(e,{})})]},s=({periods:e,selectedPeriodId:p})=>{const[c,n]=m.useState(p??null);return r.jsx(i,{periods:e??[],selectedPeriodId:c,onPeriodChange:n})},o={render:e=>r.jsx(s,{periods:e.periods,selectedPeriodId:e.selectedPeriodId}),args:{periods:a,selectedPeriodId:"period-current"}},t={render:e=>r.jsx(s,{periods:e.periods,selectedPeriodId:e.selectedPeriodId}),args:{periods:[],selectedPeriodId:null}},d={render:e=>r.jsx(s,{periods:e.periods,selectedPeriodId:e.selectedPeriodId}),args:{periods:a,selectedPeriodId:"period-current"},parameters:{viewport:{defaultViewport:"mobile1"}}};o.parameters={...o.parameters,docs:{...o.parameters?.docs,source:{originalSource:`{
  render: args => <StatefulSelector periods={args.periods} selectedPeriodId={args.selectedPeriodId} />,
  args: {
    periods: mockPeriods,
    selectedPeriodId: 'period-current'
  }
}`,...o.parameters?.docs?.source}}};t.parameters={...t.parameters,docs:{...t.parameters?.docs,source:{originalSource:`{
  render: args => <StatefulSelector periods={args.periods} selectedPeriodId={args.selectedPeriodId} />,
  args: {
    periods: [],
    selectedPeriodId: null
  }
}`,...t.parameters?.docs?.source}}};d.parameters={...d.parameters,docs:{...d.parameters?.docs,source:{originalSource:`{
  render: args => <StatefulSelector periods={args.periods} selectedPeriodId={args.selectedPeriodId} />,
  args: {
    periods: mockPeriods,
    selectedPeriodId: 'period-current'
  },
  parameters: {
    viewport: {
      defaultViewport: 'mobile1'
    }
  }
}`,...d.parameters?.docs?.source}}};export{o as Default,d as Mobile,t as NoPeriods,H as default};
