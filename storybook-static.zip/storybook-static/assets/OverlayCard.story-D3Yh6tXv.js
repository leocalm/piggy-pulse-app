import{j as e}from"./iframe-tUatgIh6.js";import{O as s}from"./OverlayCard-DgxGuVaa.js";import{S as m}from"./Stack-Caz3PGem.js";import"./preload-helper-PPVm8Dsz.js";import"./useDisplayCurrency-CYgR1z7m.js";import"./queryKeys-DbLI4zYh.js";import"./currency-DAjmKDmL.js";import"./useTranslation-Cvr3ATD0.js";import"./Paper-CwJxeiup.js";import"./polymorphic-factory-ClXRxI4s.js";import"./Group-DuVf582F.js";import"./Text-DITddzTP.js";import"./createReactComponent-CbFQ0-m9.js";import"./Badge-CcMb1JUk.js";import"./ActionIcon-qeiFNOwl.js";import"./Loader-CLPCUEQH.js";import"./Transition-wu873tAx.js";import"./UnstyledButton-YLOeXoQt.js";import"./index-D2V8dTpW.js";import"./IconTrash-fkmY6iCa.js";import"./use-resolved-styles-api-BVJotq1t.js";import"./create-safe-context-BW-8o12O.js";import"./get-auto-contrast-value-Da6zqqWm.js";const W={title:"Components/Overlays/OverlayCard",component:s,decorators:[r=>e.jsx(m,{maw:760,p:"md",children:e.jsx(r,{})})]},n={id:"overlay-1",name:"Italy Trip",icon:"🏖️",startDate:"2026-08-10",endDate:"2026-08-20",inclusionMode:"rules",spentAmount:68e3,totalCapAmount:8e4,transactionCount:23,categoryCaps:[{categoryId:"cat-1",capAmount:3e4},{categoryId:"cat-2",capAmount:4e4}]},t={args:{overlay:n,status:"active"}},a={args:{overlay:{...n,name:"Christmas Shopping",icon:"🎄",startDate:"2026-12-01",endDate:"2026-12-25",inclusionMode:"manual",spentAmount:0,totalCapAmount:5e4,transactionCount:0,categoryCaps:[]},status:"upcoming"}},o={args:{overlay:{...n,name:"Birthday Week",icon:"🎉",startDate:"2026-07-10",endDate:"2026-07-17",inclusionMode:"all",spentAmount:22e3,totalCapAmount:2e4,transactionCount:11,categoryCaps:[]},status:"past"}};t.parameters={...t.parameters,docs:{...t.parameters?.docs,source:{originalSource:`{
  args: {
    overlay: baseOverlay,
    status: 'active'
  }
}`,...t.parameters?.docs?.source}}};a.parameters={...a.parameters,docs:{...a.parameters?.docs,source:{originalSource:`{
  args: {
    overlay: {
      ...baseOverlay,
      name: 'Christmas Shopping',
      icon: '🎄',
      startDate: '2026-12-01',
      endDate: '2026-12-25',
      inclusionMode: 'manual',
      spentAmount: 0,
      totalCapAmount: 50000,
      transactionCount: 0,
      categoryCaps: []
    },
    status: 'upcoming'
  }
}`,...a.parameters?.docs?.source}}};o.parameters={...o.parameters,docs:{...o.parameters?.docs,source:{originalSource:`{
  args: {
    overlay: {
      ...baseOverlay,
      name: 'Birthday Week',
      icon: '🎉',
      startDate: '2026-07-10',
      endDate: '2026-07-17',
      inclusionMode: 'all',
      spentAmount: 22000,
      totalCapAmount: 20000,
      transactionCount: 11,
      categoryCaps: []
    },
    status: 'past'
  }
}`,...o.parameters?.docs?.source}}};export{t as Active,o as Past,a as Upcoming,W as default};
