import{j as e}from"./iframe-tUatgIh6.js";import{C}from"./CurrencyValue-Ba998bK4.js";import{u as T}from"./useDisplayCurrency-CYgR1z7m.js";import{u as B}from"./useTranslation-Cvr3ATD0.js";import{P as A}from"./Paper-CwJxeiup.js";import{S as f}from"./Stack-Caz3PGem.js";import{G as i}from"./Group-DuVf582F.js";import{T as d}from"./Text-DITddzTP.js";import{A as c}from"./ActionIcon-qeiFNOwl.js";import{N as F}from"./NumberInput-DrwO0Gn1.js";import"./preload-helper-PPVm8Dsz.js";import"./currency-DAjmKDmL.js";import"./queryKeys-DbLI4zYh.js";import"./polymorphic-factory-ClXRxI4s.js";import"./Loader-CLPCUEQH.js";import"./Transition-wu873tAx.js";import"./UnstyledButton-YLOeXoQt.js";import"./index-D2V8dTpW.js";import"./noop-BjFrJKj1.js";import"./use-resolved-styles-api-BVJotq1t.js";import"./InputBase-Cg0XTyoW.js";import"./CloseButton-BJwiWWqo.js";import"./use-uncontrolled-BF_sGqGq.js";import"./use-merged-ref-BLPPl7JB.js";const N="_addButton_ovoro_2",q="_budgetCategoryItem_ovoro_13",R="_itemActions_ovoro_43",L="_categoryIconWrapper_ovoro_97",G="_progressBar_ovoro_116",M="_progressFill_ovoro_131",P="_shimmer_ovoro_1",z="_success_ovoro_140",O="_warning_ovoro_144",W="_danger_ovoro_148",H="_breakdownItem_ovoro_168",$="_breakdownDot_ovoro_176",J="_breakdownLabel_ovoro_184",K="_breakdownValue_ovoro_190",Q="_donutCenterGradient_ovoro_199",U="_statusBadge_ovoro_207",X="_amountsSection_ovoro_219",Y="_spentAmount_ovoro_226",Z="_budgetAmount_ovoro_232",t={addButton:N,budgetCategoryItem:q,"fade-in-up":"_fade-in-up_ovoro_1",itemActions:R,categoryIconWrapper:L,progressBar:G,progressFill:M,shimmer:P,success:z,warning:O,danger:W,breakdownItem:H,breakdownDot:$,breakdownLabel:J,breakdownValue:K,donutCenterGradient:Q,statusBadge:U,amountsSection:X,spentAmount:Y,budgetAmount:Z};function S({category:o,spent:E,isEditing:_,editingValue:x,onEditStart:j,onEditCancel:w,onEditChange:k,onEditSave:I,onDelete:V,inputRef:D}){const{t:r}=B(),v=T(),s=o.budgetedValue>0?E/o.budgetedValue*100:0,b=(a=>a>100?"danger":a>=85?"warning":"success")(s);return e.jsx(A,{className:t.budgetCategoryItem,withBorder:!0,p:"lg",radius:"md",children:e.jsxs(f,{gap:"md",children:[e.jsxs(i,{justify:"space-between",align:"flex-start",children:[e.jsxs(i,{gap:"md",align:"flex-start",flex:1,children:[e.jsx("div",{className:t.categoryIconWrapper,children:o.category.icon}),e.jsxs(f,{gap:4,flex:1,children:[e.jsx(d,{fw:600,size:"sm",children:o.category.name}),e.jsxs("div",{className:t.amountsSection,children:[e.jsx("span",{className:t.spentAmount,children:e.jsx(C,{cents:E})}),e.jsxs("span",{className:t.budgetAmount,children:[r("budget.budgetedCategories.of").replace("{{budget}}",""),e.jsx(C,{cents:o.budgetedValue})]})]})]})]}),e.jsx(i,{className:t.itemActions,gap:4,children:_?e.jsxs(e.Fragment,{children:[e.jsx(c,{variant:"light",color:"blue",onClick:I,"aria-label":"Save budget category",children:e.jsx("span",{children:"✅"})}),e.jsx(c,{variant:"light",color:"gray",onClick:w,"aria-label":"Cancel budget category edit",children:e.jsx("span",{children:"❌"})})]}):e.jsxs(e.Fragment,{children:[e.jsx(c,{variant:"subtle",color:"gray",onClick:j,"aria-label":"Edit budget category",children:e.jsx("span",{children:"✏️"})}),e.jsx(c,{variant:"subtle",color:"red",onClick:V,"aria-label":"Delete budget category",children:e.jsx("span",{children:"🗑️"})})]})})]}),_&&e.jsx(F,{ref:D,value:x,onChange:a=>{const h=typeof a=="number"?a:Number.parseFloat(a||"");k(Number.isFinite(h)?h:0)},decimalScale:v.decimalPlaces,fixedDecimalScale:!0,size:"sm",variant:"filled",hideControls:!0,leftSection:e.jsx(d,{size:"sm",children:v.symbol}),placeholder:"0.00",autoFocus:!0}),e.jsxs("div",{children:[e.jsx("div",{className:t.progressBar,children:e.jsx("div",{className:`${t.progressFill} ${t[b]}`,style:{width:`${Math.min(s,100)}%`}})}),e.jsxs(i,{justify:"space-between",mt:"xs",children:[e.jsxs(d,{size:"xs",c:"dimmed",children:[s.toFixed(0),"%"," ",r(b==="success"?"budget.budgetedCategories.onTrack":b==="warning"?"budget.budgetedCategories.nearLimit":"budget.budgetedCategories.overBudget")]}),e.jsxs(d,{size:"xs",c:"dimmed",children:[e.jsx(C,{cents:Math.max(0,o.budgetedValue-E)})," ",s>100?r("budget.budgetedCategories.over"):r("budget.budgetedCategories.remaining")]})]})]})]})})}S.__docgenInfo={description:"",methods:[],displayName:"BudgetCategoryItem",props:{category:{required:!0,tsType:{name:"BudgetCategoryResponse"},description:""},spent:{required:!0,tsType:{name:"number"},description:""},isEditing:{required:!0,tsType:{name:"boolean"},description:""},editingValue:{required:!0,tsType:{name:"number"},description:""},onEditStart:{required:!0,tsType:{name:"signature",type:"function",raw:"() => void",signature:{arguments:[],return:{name:"void"}}},description:""},onEditCancel:{required:!0,tsType:{name:"signature",type:"function",raw:"() => void",signature:{arguments:[],return:{name:"void"}}},description:""},onEditChange:{required:!0,tsType:{name:"signature",type:"function",raw:"(value: number) => void",signature:{arguments:[{type:{name:"number"},name:"value"}],return:{name:"void"}}},description:""},onEditSave:{required:!0,tsType:{name:"signature",type:"function",raw:"() => void",signature:{arguments:[],return:{name:"void"}}},description:""},onDelete:{required:!0,tsType:{name:"signature",type:"function",raw:"() => void",signature:{arguments:[],return:{name:"void"}}},description:""},inputRef:{required:!1,tsType:{name:"ReactRefObject",raw:"React.RefObject<HTMLInputElement | null>",elements:[{name:"union",raw:"HTMLInputElement | null",elements:[{name:"HTMLInputElement"},{name:"null"}]}]},description:""}}};const je={title:"Components/Budget/BudgetCategoryItem",component:S,tags:["autodocs"],argTypes:{onEditStart:{action:"edit-start"},onEditCancel:{action:"edit-cancel"},onEditChange:{action:"edit-change"},onEditSave:{action:"edit-save"},onDelete:{action:"delete"}}},n={id:"1",categoryId:"cat-1",budgetPeriodId:"period-1",category:{id:"cat-1",name:"Groceries",icon:"🛒",color:"#4CAF50",parentId:null,categoryType:"Outgoing"},budgetedValue:5e4},u={args:{category:n,spent:25e3,isEditing:!1,editingValue:500,onEditStart:()=>{},onEditCancel:()=>{},onEditChange:()=>{},onEditSave:()=>{},onDelete:()=>{}}},g={args:{category:n,spent:45e3,isEditing:!1,editingValue:500,onEditStart:()=>{},onEditCancel:()=>{},onEditChange:()=>{},onEditSave:()=>{},onDelete:()=>{}}},l={args:{category:n,spent:6e4,isEditing:!1,editingValue:500,onEditStart:()=>{},onEditCancel:()=>{},onEditChange:()=>{},onEditSave:()=>{},onDelete:()=>{}}},m={args:{category:n,spent:0,isEditing:!1,editingValue:500,onEditStart:()=>{},onEditCancel:()=>{},onEditChange:()=>{},onEditSave:()=>{},onDelete:()=>{}}},p={args:{category:n,spent:25e3,isEditing:!0,editingValue:500,onEditStart:()=>{},onEditCancel:()=>{},onEditChange:()=>{},onEditSave:()=>{},onDelete:()=>{}}},y={args:{category:{...n,categoryId:"cat-2",category:{...n.category,id:"cat-2",name:"Restaurants",icon:"🍽️",color:"#FF9800"},budgetedValue:3e4},spent:18e3,isEditing:!1,editingValue:300,onEditStart:()=>{},onEditCancel:()=>{},onEditChange:()=>{},onEditSave:()=>{},onDelete:()=>{}}};u.parameters={...u.parameters,docs:{...u.parameters?.docs,source:{originalSource:`{
  args: {
    category: mockCategory,
    spent: 25000,
    // €250.00 (50%)
    isEditing: false,
    editingValue: 500,
    onEditStart: () => {},
    onEditCancel: () => {},
    onEditChange: () => {},
    onEditSave: () => {},
    onDelete: () => {}
  }
}`,...u.parameters?.docs?.source}}};g.parameters={...g.parameters,docs:{...g.parameters?.docs,source:{originalSource:`{
  args: {
    category: mockCategory,
    spent: 45000,
    // €450.00 (90%)
    isEditing: false,
    editingValue: 500,
    onEditStart: () => {},
    onEditCancel: () => {},
    onEditChange: () => {},
    onEditSave: () => {},
    onDelete: () => {}
  }
}`,...g.parameters?.docs?.source}}};l.parameters={...l.parameters,docs:{...l.parameters?.docs,source:{originalSource:`{
  args: {
    category: mockCategory,
    spent: 60000,
    // €600.00 (120%)
    isEditing: false,
    editingValue: 500,
    onEditStart: () => {},
    onEditCancel: () => {},
    onEditChange: () => {},
    onEditSave: () => {},
    onDelete: () => {}
  }
}`,...l.parameters?.docs?.source}}};m.parameters={...m.parameters,docs:{...m.parameters?.docs,source:{originalSource:`{
  args: {
    category: mockCategory,
    spent: 0,
    isEditing: false,
    editingValue: 500,
    onEditStart: () => {},
    onEditCancel: () => {},
    onEditChange: () => {},
    onEditSave: () => {},
    onDelete: () => {}
  }
}`,...m.parameters?.docs?.source}}};p.parameters={...p.parameters,docs:{...p.parameters?.docs,source:{originalSource:`{
  args: {
    category: mockCategory,
    spent: 25000,
    isEditing: true,
    editingValue: 500,
    onEditStart: () => {},
    onEditCancel: () => {},
    onEditChange: () => {},
    onEditSave: () => {},
    onDelete: () => {}
  }
}`,...p.parameters?.docs?.source}}};y.parameters={...y.parameters,docs:{...y.parameters?.docs,source:{originalSource:`{
  args: {
    category: {
      ...mockCategory,
      categoryId: 'cat-2',
      category: {
        ...mockCategory.category,
        id: 'cat-2',
        name: 'Restaurants',
        icon: '🍽️',
        color: '#FF9800'
      },
      budgetedValue: 30000 // €300.00
    },
    spent: 18000,
    // €180.00 (60%)
    isEditing: false,
    editingValue: 300,
    onEditStart: () => {},
    onEditCancel: () => {},
    onEditChange: () => {},
    onEditSave: () => {},
    onDelete: () => {}
  }
}`,...y.parameters?.docs?.source}}};export{p as EditingMode,g as NearLimit,m as NotStarted,u as OnTrack,l as OverBudget,y as RestaurantCategory,je as default};
