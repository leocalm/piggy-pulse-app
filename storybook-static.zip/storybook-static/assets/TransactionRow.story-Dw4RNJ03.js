import{j as e}from"./iframe-tUatgIh6.js";import{T as m,a as c}from"./TransactionRow-DtJ3cfNf.js";import"./preload-helper-PPVm8Dsz.js";import"./currency-DAjmKDmL.js";import"./useDisplayCurrency-CYgR1z7m.js";import"./queryKeys-DbLI4zYh.js";import"./AccountBadge-XVeDKXH0.js";import"./IconMap-BmnnbRCH.js";import"./createReactComponent-CbFQ0-m9.js";import"./polymorphic-factory-ClXRxI4s.js";import"./Text-DITddzTP.js";import"./UnstyledButton-YLOeXoQt.js";import"./index-D2V8dTpW.js";import"./CategoryBadge-kwQiUj7j.js";import"./useTranslation-Cvr3ATD0.js";import"./Group-DuVf582F.js";import"./create-safe-context-BW-8o12O.js";import"./ScrollArea-CL2WNbgG.js";import"./floating-ui.react-w8eZEK3t.js";import"./use-merged-ref-BLPPl7JB.js";const U={title:"Components/Transactions/TransactionRow",component:m,decorators:[s=>e.jsx(c,{verticalSpacing:"sm",highlightOnHover:!0,striped:"even",style:{background:"#151b26",borderRadius:"16px",border:"1px solid rgba(255, 255, 255, 0.06)",overflow:"hidden"},children:e.jsx(c.Tbody,{children:e.jsx(s,{})})})]},t={id:"1",name:"ING",color:"#ff6600",icon:"💳",accountType:"Checking",currency:{id:"1",name:"Euro",symbol:"€",currency:"EUR",decimalPlaces:2},balance:15e4,balancePerDay:[],balanceChangeThisPeriod:0,transactionCount:0},d={id:"c1",name:"Comida",color:"#b47aff",icon:"🍔",parentId:null,categoryType:"Outgoing"},l={id:"v1",name:"McDonald's"},i={id:"t1",description:"Lunch at Restaurant",amount:4550,occurredAt:"2026-01-16",category:d,fromAccount:t,toAccount:null,vendor:l},p={id:"t3",description:"Salary January",amount:324500,occurredAt:"2026-01-01",category:{id:"c3",name:"Salary",color:"#00ffa3",icon:"💰",parentId:null,categoryType:"Incoming"},fromAccount:t,toAccount:null,vendor:{id:"v2",name:"Company Inc."}},u={id:"t2",description:"Savings Transfer",amount:5e4,occurredAt:"2026-01-12",category:{id:"c2",name:"Transferência",color:"#00d4ff",icon:"💸",parentId:null,categoryType:"Transfer"},fromAccount:t,toAccount:{id:"2",name:"Poupança",color:"#00ffa3",icon:"🏦",accountType:"Savings",currency:{id:"1",name:"Euro",symbol:"€",currency:"EUR",decimalPlaces:2},balance:5e5,balancePerDay:[],balanceChangeThisPeriod:0,transactionCount:0},vendor:null},n={args:{transaction:i,onEdit:()=>{},onDelete:()=>{}}},o={args:{transaction:p,onEdit:()=>{},onDelete:()=>{}}},r={args:{transaction:u,onEdit:()=>{},onDelete:()=>{}}},a={args:{transaction:i,onEdit:()=>{},onDelete:()=>{},animationDelay:.2}};n.parameters={...n.parameters,docs:{...n.parameters?.docs,source:{originalSource:`{
  args: {
    transaction: regularTransaction,
    onEdit: () => {},
    onDelete: () => {}
  }
}`,...n.parameters?.docs?.source}}};o.parameters={...o.parameters,docs:{...o.parameters?.docs,source:{originalSource:`{
  args: {
    transaction: incomeTransaction,
    onEdit: () => {},
    onDelete: () => {}
  }
}`,...o.parameters?.docs?.source}}};r.parameters={...r.parameters,docs:{...r.parameters?.docs,source:{originalSource:`{
  args: {
    transaction: transferTransaction,
    onEdit: () => {},
    onDelete: () => {}
  }
}`,...r.parameters?.docs?.source}}};a.parameters={...a.parameters,docs:{...a.parameters?.docs,source:{originalSource:`{
  args: {
    transaction: regularTransaction,
    onEdit: () => {},
    onDelete: () => {},
    animationDelay: 0.2
  }
}`,...a.parameters?.docs?.source}}};export{o as Incoming,n as Outgoing,r as Transfer,a as WithAnimationDelay,U as default};
