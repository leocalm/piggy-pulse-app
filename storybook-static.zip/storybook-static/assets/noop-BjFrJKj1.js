const o=()=>{};export{o as n};
